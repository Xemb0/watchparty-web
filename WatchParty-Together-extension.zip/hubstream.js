/* Fetch from the viewer's source origin, preserving the mobile resolver contract. */
var WatchPartyHubstream=(()=>{
 const sessions=new Map();
 async function resolve(id){
  if(typeof id!=='string'||! /^[A-Za-z0-9]{1,100}$/.test(id))throw Error('Invalid Hubstream identity');
  const url='https://hubstream.art/#'+id;
  let tab=(await chrome.tabs.query({url:'https://hubstream.art/*'})).find(t=>t.url===url),owned=false,created=false;
  if(tab&&sessions.get(id)?.tabId===tab.id)owned=!!sessions.get(id).owned;
  try{
   if(!tab){tab=await chrome.tabs.create({url,active:false});owned=true;created=true;}
   const deadline=Date.now()+15000;
   while(tab.status!=='complete'&&Date.now()<deadline){await new Promise(r=>setTimeout(r,250));tab=await chrome.tabs.get(tab.id);}
   if(tab.url!==url||tab.status!=='complete')throw Error('Source page unavailable');
   const result=await chrome.scripting.executeScript({target:{tabId:tab.id},args:[id],func:async videoId=>{
    if(location.origin!=='https://hubstream.art'||location.hash!=='#'+videoId)return null;
    const response=await fetch('/api/v1/video?id='+encodeURIComponent(videoId)+'&w=1920&h=1080&r=',{signal:AbortSignal.timeout(12000)});
    if(!response.ok)return null;
    const reader=response.body.getReader();let body='',length=0;const decoder=new TextDecoder();
    try{for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>262144)return null;body+=decoder.decode(value,{stream:true});}return body+decoder.decode();}
    finally{await reader.cancel();}
   }});
   const body=result[0]?.result?.trim();
   if(typeof body!=='string'||body.length>262144||! /^[0-9a-f]+$/i.test(body))throw Error('Hubstream resolver unavailable');
   const decoderKey=await crypto.subtle.importKey('raw',new TextEncoder().encode('kiemtienmua911ca'),{name:'AES-CBC'},false,['decrypt']);
   const plain=await crypto.subtle.decrypt({name:'AES-CBC',iv:new TextEncoder().encode('1234567890oiuytr')},decoderKey,Uint8Array.from(body.match(/../g),v=>parseInt(v,16)));
   const source=new URL(JSON.parse(new TextDecoder().decode(plain)).source);
   if(source.protocol!=='https:'||source.username||source.password)throw Error('Invalid Hubstream source');
   sessions.set(id,{tabId:tab.id,owned,origin:source.origin});created=false;
   return body;
  }finally{if(created&&tab?.id!=null&&tab.url===url)await chrome.tabs.remove(tab.id).catch(()=>{});}
 }
 async function resource(id,url){
  let session=sessions.get(id);if(!session){await resolve(id);session=sessions.get(id);}
  const target=new URL(url);
  if(target.origin!==session.origin||target.protocol!=='https:'||target.username||target.password)throw Error('Unrecognized Hubstream media');
  const tab=await chrome.tabs.get(session.tabId);
  if(tab.url!=='https://hubstream.art/#'+id){sessions.delete(id);throw Error('Source page changed');}
  const results=await chrome.scripting.executeScript({target:{tabId:session.tabId},args:[id,url],func:async(videoId,mediaUrl)=>{
   if(location.origin!=='https://hubstream.art'||location.hash!=='#'+videoId)return null;
   const response=await fetch(mediaUrl,{credentials:'omit',signal:AbortSignal.timeout(20000)});if(!response.ok)return {status:response.status};
   const reader=response.body.getReader(),chunks=[];let size=0;
   try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8388608)return {status:413};chunks.push(value);}}
   finally{await reader.cancel();}
   let binary='';for(const bytes of chunks)for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
   return {status:response.status,data:btoa(binary)};
  }});
  const result=results[0]?.result;if(!result?.data)throw Error('Hubstream media unavailable'+(result?.status?' (HTTP '+result.status+')':''));return result;
 }
 async function closeOwned(){for(const [id,s] of sessions){if(s.owned){const tab=await chrome.tabs.get(s.tabId).catch(()=>null);if(tab?.url==='https://hubstream.art/#'+id)await chrome.tabs.remove(s.tabId).catch(()=>{});}sessions.delete(id);}}
 return {resolve,resource,closeOwned};
})();
