const status=document.querySelector('#status'),start=document.querySelector('#start');
const send=async payload=>{let timer;try{return await Promise.race([chrome.runtime.sendMessage({from:'popup',...payload}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Room did not respond. Reload WatchParty and try again.')),20000);})]);}finally{clearTimeout(timer);}};
let source;
const find=document.querySelector('#find');
async function findVideos(){
 find.disabled=true;status.textContent='Finding videos…';
 try{
  const result=await send({type:'inspect'});
  if(!result?.ok)throw Error('Could not scan this page.');
  source=result.source;
  start.hidden=!source;
  document.querySelector('#title').textContent=source?.title||'Watch with your friends';
  if(source)start.textContent=source.mode==='embed'?'Play in room':'Watch together';
  renderVideos(result.videos||[]);
  if(!(result.videos?.length))status.textContent=!result.room?'Join a WatchParty room to choose a video.':source?'Video found. Ready to watch together.':'No video found. Start the video on this page, then try again.';
  document.querySelector('#call').hidden=!result.room;
  document.querySelector('#room').textContent=result.room?'Return to room':'Open WatchParty';
 }catch(_){status.textContent='Could not scan this page. Reload it, then try again.';}
 finally{find.disabled=false;}
}
find.onclick=findVideos;
findVideos();
start.onclick=async()=>{start.disabled=true;try{const result=await send({type:'handoff'});if(!result?.ok)throw Error('handoff failed');window.close();}catch(_){status.textContent='Could not open your room. The video is still playing.';start.disabled=false;}};
document.querySelector('#room').onclick=()=>send({type:'openRoom'}).then(()=>window.close());
document.querySelector('#call').onclick=()=>send({type:'floatCall'}).then(r=>{if(r?.ok)window.close();else status.textContent='Open your room and choose Float call.';});

function renderVideos(videos){
 const list=document.querySelector('#videos');list.replaceChildren();
 for(const video of videos){
  const card=document.createElement('button');card.type='button';
  const preview=document.createElement('span');preview.className='preview';preview.textContent='▶';card.append(preview);
  if(video.thumbnail && (/^https:\/\//.test(video.thumbnail)||/^data:image\/(jpeg|png);base64,/.test(video.thumbnail))){
   const image=document.createElement('img');image.src=video.thumbnail;image.alt='';image.referrerPolicy='no-referrer';image.onerror=()=>image.remove();preview.append(image);
  }
  const title=document.createElement('span');title.className='video-title';title.textContent=video.title||'Detected video';card.append(title);
  const action=document.createElement('small');action.textContent=(video.duration||'Video')+(video.mode==='page'?' · Watch together in this tab':' · Play in room');card.append(action);
  card.onclick=async()=>{card.disabled=true;status.textContent='Sending video…';try{const r=await send({type:'pageHandoff',url:video.url});if(!r?.ok)throw Error(r?.error||'Could not send this video.');status.textContent='Sent to room. Playback is checked there.';}catch(e){status.textContent=e.message;}finally{card.disabled=false;}};
  list.append(card);
 }
 if(videos.length)status.textContent='Choose a video. Site pop-up tabs are blocked while this picker is active.';
}

// Keep drag/close controls inside the isolated frame, away from site ad handlers.
if(window.parent!==window){
 document.body.classList.add('floating');
 const header=document.querySelector('header'),close=document.querySelector('#dismiss');
 close.hidden=false;close.onclick=()=>window.parent.postMessage({wpPicker:'close'},'*');
 let pointer=null;
 header.onpointerdown=e=>{if(e.target.closest('button')||e.button!==0)return;pointer={id:e.pointerId,x:e.screenX,y:e.screenY};header.setPointerCapture(e.pointerId);e.preventDefault();};
 header.onpointermove=e=>{if(!pointer||pointer.id!==e.pointerId)return;window.parent.postMessage({wpPicker:'move',dx:e.screenX-pointer.x,dy:e.screenY-pointer.y},'*');pointer.x=e.screenX;pointer.y=e.screenY;};
 header.onpointerup=header.onpointercancel=()=>{pointer=null;};
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close.click();});
}
