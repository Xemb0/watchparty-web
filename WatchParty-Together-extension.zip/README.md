# WatchParty Together — browser extension

Syncs a real streaming tab (Netflix, Prime Video, Disney+, Hulu, Max,
JioHotstar, Crunchyroll) with a WatchParty room, because those services
cannot render inside the web app page (`frame-ancestors` + DRM restrictions).
This is the web twin of the mobile apps' in-app WebView co-watch player and
speaks the same sync protocol (`web_sync.js` semantics, `CoWatchState` over
the LiveKit data channel).

## How it works

```
app.watchparty.online (wasm app — room, voice, chat, LiveKit)
        ⇅ window.postMessage           {wpExt:"app"/"ext", json}
content/app-bridge.js                   (extension, app tab)
        ⇅ chrome.runtime messaging
background.js                           (service worker — routes, opens tabs)
        ⇅ chrome.tabs messaging
content/sync.js                         (extension, streaming tab)
        ⇅ DOM                           observe/drive the <video> + rail pill
netflix.com / primevideo.com / …        (user's own account, top-level DRM)
```

- **Host (web)**: tap an OTT tile in the room → extension opens the service
  in a tab → log in, press play → the app starts the shared session from the
  tab's watch URL and the host's real play/pause/seek drive the room.
- **Participant (web)**: the session's watch URL opens in their own tab (own
  login) and the room's commands drive that tab's video. The app tab shows a
  status card; the streaming tab shows the WatchParty rail pill
  (Hosting/Synced · paused) so the user never needs to switch back.
- Mobile hosts/participants interoperate unchanged — same session state.

## Install (dev)

1. Chrome/Edge/Brave → `chrome://extensions` → enable **Developer mode**.
2. **Load unpacked** → select this `extension/` folder.
3. Open the web app (app.watchparty.online or localhost dev), create/join a
   room, tap Netflix/Prime in the picker.

`http://localhost/*` and `http://127.0.0.1/*` are in the manifest for local
dev of the wasm app.

## Packaging (store upload)

```bash
cd extension && zip -r ../watchparty-extension.zip . -x '.*' && cd ..
```

Upload the zip in the Chrome Web Store developer console. The model
(content-script sync of a streaming tab the user controls, on their own
account) is the same store-approved territory as Teleparty; no request
interception, no DRM touching, no data collection — worth stating in the
listing's privacy declarations.

## Protocol notes

All payloads are JSON strings in a `json` field. App→extension:
`ping | open{url} | command{action, positionSec, seq} | state{phase, isHost} | close`.
Extension→app: `pong{version} | ready/event{action, position, duration,
playing, url, title, ts} | tabClosed`.

Kotlin side: `cowatch/webview/CoWatchExtension.kt` (expect),
`CoWatchExtension.wasmJs.kt` (bridge + host glue),
`CoWatchWebPlayer.wasmJs.kt` (participant pipe + status card).

Keep the sync core of `content/sync.js` behaviourally identical to
`composeApp/src/commonMain/composeResources/files/cowatch/web_sync.js`.
