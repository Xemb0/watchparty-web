/* Resolve Drive renditions in this viewer's browser session, never in room state. */
var WatchPartyDrive = (() => {
  function streams(body) {
    const fields=new URLSearchParams(body);
    if(fields.get('status')!=='ok')return [];
    return (fields.get('fmt_stream_map')||'').split(',').flatMap(entry=>{
      const bar=entry.indexOf('|');if(bar<0)return [];
      const [itag,size]=entry.slice(0,bar).split('/');
      if(!['18','22','37'].includes(itag))return []; // Drive's H.264/AAC MP4 renditions.
      try {
        const url=new URL(entry.slice(bar+1));
        if(url.protocol!=='https:'||url.username||url.password||!url.hostname.endsWith('.c.drive.google.com')||url.pathname!=='/videoplayback')return [];
        return [{url:url.href,height:Number(size?.split('x')[1])||({'18':360,'22':720,'37':1080}[itag])}];
      }catch(_){return [];}
    }).sort((a,b)=>b.height-a.height);
  }
  async function resolve(id,fetcher=fetch) {
    if(typeof id!=='string'||! /^[a-zA-Z0-9_-]{1,200}$/.test(id))throw Error('Invalid Drive file');
    const signal=AbortSignal.timeout(15000);
    const response=await fetcher('https://drive.google.com/get_video_info?docid='+encodeURIComponent(id)+'&drive_originator_app=303',{credentials:'include',signal});
    if(!response.ok)throw Error('Drive video unavailable');
    const body=await response.text();
    if(body.length>2000000)throw Error('Drive video unavailable');
    for(const candidate of streams(body)) {
      const check=await fetcher(candidate.url,{credentials:'include',headers:{Range:'bytes=0-7'},signal});
      const valid=check.ok&&/^video\/mp4(?:;|$)/i.test(check.headers.get('content-type')||'');
      await check.body?.cancel();
      if(valid)return candidate;
    }
    throw Error('Drive preview unavailable. Check file access or try again after Drive finishes processing.');
  }

  // Original media stays in the requesting browser. Cache only Google's local
  // confirmation URL; never send it, cookies, or access tokens into room state.
  const originalUrls=new Map();
  async function limitedBody(response,limit){
    const reader=response.body.getReader(),chunks=[];let length=0;
    try{for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>limit)throw Error('Drive response too large');chunks.push(value);}}
    finally{await reader.cancel().catch(()=>{});}
    const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return bytes;
  }
  async function readOriginal(id,start,length,fetcher=fetch){
    if(typeof id!=='string'||!/^[\w-]{1,200}$/.test(id)||!Number.isSafeInteger(start)||start<0||!Number.isInteger(length)||length<1||length>1048576)throw Error('Invalid Drive range');
    const key=fetcher===fetch?id:null;
    let url=(key&&originalUrls.get(key)?.expires>Date.now())?originalUrls.get(key).url:'https://drive.usercontent.google.com/download?id='+encodeURIComponent(id)+'&export=download&confirm=t';
    const options={credentials:'include',headers:{Range:`bytes=${start}-${start+length-1}`},signal:AbortSignal.timeout(20000)};
    let response=await fetcher(url,options);
    if((response.headers.get('content-type')||'').includes('text/html')){
      const html=new TextDecoder().decode(await limitedBody(response,1048576));
      const form=html.match(/<form\b[^>]*action="([^"]+)"[^>]*>([\s\S]*?)<\/form>/i);
      if(!form)throw Error('Drive original unavailable');
      const decode=value=>value.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'");
      const action=new URL(decode(form[1]));
      if(action.protocol!=='https:'||action.hostname!=='drive.usercontent.google.com'||action.pathname!=='/download'||action.username||action.password)throw Error('Invalid Drive confirmation');
      for(const input of form[2].matchAll(/<input\b[^>]*>/gi)){
        const name=input[0].match(/\bname="([^"]*)"/i)?.[1],value=input[0].match(/\bvalue="([^"]*)"/i)?.[1];
        if(['id','export','confirm','uuid','at'].includes(name))action.searchParams.set(name,decode(value||''));
      }
      if(action.searchParams.get('id')!==id)throw Error('Drive identity changed');
      url=action.href;response=await fetcher(url,options);
    }
    const range=(response.headers.get('content-range')||'').match(/^bytes (\d+)-(\d+)\/(\d+)$/);
    if(response.status!==206||!range||Number(range[1])!==start||Number(range[2])>=start+length||!Number.isSafeInteger(Number(range[3]))||Number(range[3])<=Number(range[2])){
      await response.body?.cancel();throw Error('Drive original range unavailable');
    }
    const bytes=await limitedBody(response,length);
    if(bytes.length!==Number(range[2])-start+1)throw Error('Incomplete Drive range');
    if(key){if(originalUrls.size>=16)originalUrls.delete(originalUrls.keys().next().value);originalUrls.set(key,{url,expires:Date.now()+300000});}
    return {bytes,size:Number(range[3])};
  }
  return {streams,resolve,readOriginal};
})();
