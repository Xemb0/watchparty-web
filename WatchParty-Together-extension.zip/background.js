/*
 * WatchParty Together — MV3 service worker.
 *
 * Pure message router between exactly two tabs:
 *   - the APP tab   (app.watchparty.online — holds the room / LiveKit / voice)
 *   - the SYNC tab  (netflix.com / primevideo.com / … — plays the video)
 *
 * All payloads travel as JSON *strings* (`json` field) so the page, the
 * content scripts and the Kotlin/Wasm app all speak one flat protocol:
 *   app  → ext : {type:"ping"|"open"|"command"|"state"|"close", ...}
 *   sync → app : {type:"ready"|"event", action, position, duration, playing,
 *                 url, title, ts}   |   {type:"tabClosed"}
 *
 * Tab ids are mirrored to storage.session because MV3 workers are killed at
 * idle — the next message re-loads them, so routing survives restarts.
 */

let appTabId = null;
let streamTabId = null;
let loaded = false;

async function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  try {
    const s = await chrome.storage.session.get(["appTabId", "streamTabId"]);
    if (appTabId == null) appTabId = s.appTabId ?? null;
    if (streamTabId == null) streamTabId = s.streamTabId ?? null;
  } catch (e) {}
}

function save() {
  try { chrome.storage.session.set({ appTabId, streamTabId }); } catch (e) {}
}

const APP_URLS = [
  "https://app.watchparty.online/*",
  "https://watchparty.online/*",
  "http://localhost/*",
  "http://127.0.0.1/*",
];

async function relayToApp(json) {
  await ensureLoaded();
  if (appTabId != null) {
    try {
      await chrome.tabs.sendMessage(appTabId, { from: "ext", json });
      return;
    } catch (e) { appTabId = null; }
  }
  // App tab unknown (worker restarted / tab reloaded) — find it again.
  try {
    const tabs = await chrome.tabs.query({ url: APP_URLS });
    if (tabs.length) {
      appTabId = tabs[0].id;
      save();
      chrome.tabs.sendMessage(appTabId, { from: "ext", json }).catch(() => {});
    }
  } catch (e) {}
}

async function openOrFocus(url) {
  await ensureLoaded();
  if (streamTabId != null) {
    try {
      const tab = await chrome.tabs.get(streamTabId);
      // Same page already open → just focus; don't reload out from under a
      // playing video. Different title → navigate the existing sync tab.
      const same = tab.url && url && tab.url.split("?")[0] === url.split("?")[0];
      await chrome.tabs.update(streamTabId, same ? { active: true } : { url, active: true });
      if (tab.windowId != null) chrome.windows.update(tab.windowId, { focused: true });
      return;
    } catch (e) { streamTabId = null; }
  }
  const tab = await chrome.tabs.create({ url });
  streamTabId = tab.id;
  save();
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || !m.from) return;
  (async () => {
    await ensureLoaded();
    if (m.from === "app") {
      if (sender.tab?.id != null && sender.tab.id !== appTabId) {
        appTabId = sender.tab.id;
        save();
      }
      let msg = {};
      try { msg = JSON.parse(m.json || "{}"); } catch (e) {}
      if (msg.type === "open" && msg.url) {
        openOrFocus(msg.url);
      } else if (msg.type === "hello" || msg.type === "ping") {
        // presence only — the app-bridge already pong'd on the page side
      } else if (streamTabId != null) {
        chrome.tabs.sendMessage(streamTabId, { from: "ext-bg", json: m.json }).catch(() => {});
      }
    } else if (m.from === "sync") {
      if (sender.tab?.id != null && sender.tab.id !== streamTabId) {
        streamTabId = sender.tab.id;
        save();
      }
      relayToApp(m.json);
    }
  })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === streamTabId) {
    streamTabId = null;
    save();
    relayToApp(JSON.stringify({ type: "tabClosed" }));
  }
  if (tabId === appTabId) {
    appTabId = null;
    save();
  }
});
