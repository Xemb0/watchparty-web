async function boundedRead(promise,ms=10000){
 let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Room did not respond. Reload WatchParty and try again.')),ms);})]);}finally{clearTimeout(timer);}
}
/* WatchParty Together — one app-owned session, closed at its tab boundary. */
importScripts('content/urls.js');
importScripts('drive.js');
importScripts('hubstream.js');
let appTabId = null;
let streamTabId = null;
let streamOrigin = null;
let loaded = false;
let activeRoom = null;
let pendingHandoff = null;
let requestSerial = 0;
let autoMode = false;
let autoGeneration = 0;
let autoTimer = null;
let autoTargetTabId = null;
const discoveryRequests = new Map();
// Serialize tab/message mutations so a slow open cannot resurrect a closed session.
let pending = Promise.resolve();
function enqueue(fn) {
  pending = pending.then(async () => { await ensureLoaded(); await fn(); }).catch(() => {});
}
const validHttpUrl = WatchPartyUrls.shareable;
const isApprovedAppUrl = WatchPartyUrls.approvedApp;
function isLinkedSource(tab) {
  const url = validHttpUrl(tab.pendingUrl || tab.url);
  return !!url && new URL(url).origin === streamOrigin;
}

async function save() {
  // In-memory shutdown must still complete if session storage is unavailable.
  try { await chrome.storage.session.set({ appTabId, streamTabId, streamOrigin, activeRoom, pendingHandoff }); } catch (_) {}
}
async function relayToTab(tabId, payload) {
  if (tabId == null) return;
  try { return await chrome.tabs.sendMessage(tabId, { from: 'ext-bg', json: JSON.stringify(payload) }); } catch (_) {}
}
async function stopDiscovery() {
  autoMode = false;
  autoGeneration++;
  if (autoTimer !== null) clearTimeout(autoTimer);
  autoTimer = null;
  const targets = new Set([...discoveryRequests.values()].map(r => r.targetTabId));
  if (autoTargetTabId != null) targets.add(autoTargetTabId);
  autoTargetTabId = null;
  discoveryRequests.clear();
  for (const id of targets) await relayToTab(id, {type:'cancelDiscovery'});
}
async function closeSession() {
  const oldStream = streamTabId;
  streamTabId = null;
  streamOrigin = null;
  appTabId = null;
  await save();
  await stopDiscovery();
  await relayToTab(oldStream, {type:'close'});
}
async function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  const stored = await chrome.storage.session.get(['appTabId', 'streamTabId', 'streamOrigin', 'activeRoom', 'pendingHandoff']);
  activeRoom = stored.activeRoom ?? null;
  pendingHandoff = stored.pendingHandoff ?? null;
  if (pendingHandoff && Date.now() - pendingHandoff.createdAt > 20 * 60 * 1000) pendingHandoff = null;
  appTabId = stored.appTabId ?? null;
  streamTabId = stored.streamTabId ?? null;
  streamOrigin = stored.streamOrigin ?? null;
  if (appTabId == null && streamTabId == null) return;
  try {
    const app = await chrome.tabs.get(appTabId);
    if (!isApprovedAppUrl(app.url)) throw Error('app left');
    if (streamTabId != null) {
      const stream = await chrome.tabs.get(streamTabId);
      if (!isLinkedSource(stream)) throw Error('stream left');
    }
  } catch (_) { await closeSession(); }
}
async function relayToApp(payload) {
  if (appTabId == null) return;
  try {
    const app = await chrome.tabs.get(appTabId);
    if (!isApprovedAppUrl(app.url)) { await closeSession(); return; }
    // The app bridge deliberately listens for "ext", unlike source tabs.
    await chrome.tabs.sendMessage(appTabId, {from:'ext', json:JSON.stringify(payload)});
  } catch (_) { await closeSession(); }
}
async function activateStream() {
  if (streamTabId == null || appTabId == null) return;
  try {
    const tab = await chrome.tabs.get(streamTabId);
    if (!isLinkedSource(tab)) { await closeSession(); return; }
    if (tab.pendingUrl || !tab.url) return; // The committed document will handshake.
    await chrome.scripting?.executeScript({target:{tabId:streamTabId},files:['content/urls.js','content/sync.js']}).catch(()=>{});
    await relayToTab(streamTabId, {type:'activate'});
  } catch (_) { await closeSession(); }
}

async function refreshActiveRoom() {
  const tabs = await chrome.tabs.query({url:['https://app.watchparty.online/*','https://watchparty.online/*']});
  const rooms = [];
  for (const tab of tabs) {
    if (!isApprovedAppUrl(tab.url)) continue;
    try {
      const results = await boundedRead(chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',
        func:()=>{
          if(typeof window.__wp_room_status === 'function')return window.__wp_room_status();
          const call=window.__wp_lk_room;
          return window.__wp_room_callbacks && call?.state==='connected' && call.name ? {roomId:call.name} : null;
        }}));
      const state = results[0]?.result;
      if (state?.roomId) rooms.push({appTabId:tab.id,roomId:state.roomId,isHost:!!state.isHost});
      // Older loaded pages do not expose status; retain their reported ownership.
      else if (state === undefined && activeRoom?.appTabId === tab.id) rooms.push(activeRoom);
    } catch (_) {
      if (activeRoom?.appTabId === tab.id) rooms.push(activeRoom);
    }
  }
  const selected = rooms.find(r=>r.appTabId===activeRoom?.appTabId) || rooms.find(r=>r.appTabId===appTabId) || rooms[0] || null;
  if (selected && appTabId != null && selected.appTabId !== appTabId && streamTabId != null) await closeSession();
  activeRoom = selected;
  if (selected) appTabId = selected.appTabId;
  await save();
}

async function openRoom() {
  await refreshActiveRoom();
  let tab;
  const ownerId = activeRoom?.appTabId ?? appTabId;
  if (ownerId != null) {
    try { tab = await chrome.tabs.get(ownerId); } catch (_) {}
  }
  if (!tab || !isApprovedAppUrl(tab.url)) {
    tab = (await chrome.tabs.query({url:['https://app.watchparty.online/*','https://watchparty.online/*']}))
      .find(t => isApprovedAppUrl(t.url));
  }
  if (tab) {
    await chrome.tabs.update(tab.id, {active:true});
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, {focused:true});
  } else tab = await chrome.tabs.create({url:'https://app.watchparty.online',active:true});
  return tab;
}
chrome.action.onClicked.addListener(() => enqueue(openRoom));

function canonicalSource(value) {
  const valid = validHttpUrl(value);
  if (!valid) return null;
  const u = new URL(valid), h = u.hostname;
  if (['youtube.com','www.youtube.com','m.youtube.com','youtu.be'].includes(h)) {
    const id = h === 'youtu.be' ? u.pathname.slice(1) : u.searchParams.get('v');
    return /^[\w-]{11}$/.test(id || '') ? 'https://www.youtube.com/watch?v=' + id : null;
  }
  if ((h === 'netflix.com' || h.endsWith('.netflix.com')) && /^\/watch\/\d+/.test(u.pathname)) return u.origin + u.pathname;
  if ((h === 'primevideo.com' || h.endsWith('.primevideo.com')) && /\/(detail|gp\/video|watch)\//.test(u.pathname)) return u.origin + u.pathname;
  return null;
}
async function ensureAppBridge(tabId) {
  const ready=await chrome.tabs.sendMessage(tabId,{from:'ext',json:JSON.stringify({type:'bridgeCheck'})}).catch(()=>null);
  if(ready?.ready)return;
  await chrome.scripting.executeScript({target:{tabId},files:['content/urls.js','content/app-bridge.js']});
}
async function deliverHandoff() {
  if (!pendingHandoff) return;
  try {
    const tab = await chrome.tabs.get(pendingHandoff.appTabId);
    if (isApprovedAppUrl(tab.url)) {
      await ensureAppBridge(tab.id);
      await chrome.tabs.sendMessage(tab.id, {from:'ext',json:JSON.stringify({...pendingHandoff,type:'handoff'})});
    }
  } catch (_) {}
}
async function floatOwnedCall() {
  await refreshActiveRoom();
  const id=activeRoom?.appTabId;
  if(id==null)return false;
  const tab=await chrome.tabs.get(id);
  if(!isApprovedAppUrl(tab.url))return false;
  const results=await chrome.scripting.executeScript({target:{tabId:id},world:'MAIN',func:()=>window.__wp_call_float?.()||false});
  return !!results[0]?.result;
}
async function beginHandoff(source, payload) {
  const url = canonicalSource(source.url);
  if (!url || canonicalSource(payload.url) !== url) return;
  const mode = url.startsWith('https://www.youtube.com/') && payload.mode !== 'provider' ? 'embed' : 'provider';
  if (activeRoom) {
    try { const tab = await chrome.tabs.get(activeRoom.appTabId); if (isApprovedAppUrl(tab.url)) appTabId = tab.id; } catch (_) { activeRoom = null; }
  }
  if(mode==='provider'&&activeRoom)await floatOwnedCall().catch(()=>false);
  const app = await openRoom();
  pendingHandoff = {requestId:Date.now().toString(36)+'-'+(++requestSerial),createdAt:Date.now(),sourceTabId:source.id,appTabId:app.id,
    mode,url,position:Math.max(0,Math.min(Number(payload.position)||0,86400)),title:String(payload.title||'').slice(0,200)};
  appTabId = app.id;
  await save();
  await relayToTab(source.id,{type:'handoffStarted',requestId:pendingHandoff.requestId,url});
  await deliverHandoff();
}
async function finishHandoff(payload, sender) {
  const request = pendingHandoff;
  if (!request || sender.id !== request.appTabId || payload.requestId !== request.requestId || validHttpUrl(payload.url) !== request.url) return;
  const source = await chrome.tabs.get(request.sourceTabId).catch(()=>null);
  if (!source || (request.sourceUrl ? validHttpUrl(source.url)!==request.sourceUrl : canonicalSource(source.url)!==request.url)) { pendingHandoff=null; await save(); return; }
  if (payload.status === 'playing' && ['embed','direct','page'].includes(request.mode)) {
    const result=await relayToTab(source.id,{type:'handoffComplete',requestId:request.requestId,url:request.url});
    if (!result?.paused) return;
    await chrome.tabs.sendMessage(request.appTabId,{from:'ext',json:JSON.stringify({type:'handoffCommitted',requestId:request.requestId})});
    pendingHandoff=null;
  } else if (payload.status === 'provider' || payload.status === 'fallback') {
    if (streamTabId !== source.id) await relayToTab(streamTabId,{type:'close'});
    appTabId=request.appTabId; streamTabId=source.id; streamOrigin=new URL(source.url).origin;
    await activateStream();
    await chrome.tabs.update(source.id,{active:true});
    pendingHandoff=null;
  } else if (payload.status === 'cancelled') pendingHandoff=null;
  // An embedding failure deliberately retains the original source and request
  // so the explicit Watch in YouTube tab fallback can finish it later.
  await save();
}

async function openOrFocus(url) {
  const valid = validHttpUrl(url);
  if (!valid) return;
  let tab;
  if (streamTabId != null) {
    await relayToTab(streamTabId, {type:'close'});
    try {
      tab = await chrome.tabs.get(streamTabId);
      tab = await chrome.tabs.update(streamTabId, tab.url === valid ? {active:true} : {url:valid, active:true});
    } catch (_) { tab = null; }
  }
  if (!tab) tab = await chrome.tabs.create({url:valid, active:true});
  streamTabId = tab.id;
  streamOrigin = new URL(valid).origin;
  await save();
  if (tab.windowId != null) await chrome.windows.update(tab.windowId, {focused:true});
  await activateStream(); // New documents also handshake after content-script injection.
}

async function sendDiscoveryWhenReady(requestId) {
  const request = discoveryRequests.get(requestId);
  if (!request) return;
  for (let attempt = 0; attempt < 20; attempt++) {
    if (discoveryRequests.get(requestId) !== request) return;
    try {
      const tab = await chrome.tabs.get(request.targetTabId);
      if (discoveryRequests.get(requestId) !== request) return;
      if (tab.status === 'complete') {
        if (validHttpUrl(tab.url) !== request.url) break;
        await chrome.tabs.sendMessage(request.targetTabId, {from:'ext-bg', json:JSON.stringify({type:'discover',requestId,canonicalUrl:request.url,localPlayback:!request.auto})});
        return;
      }
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  enqueue(async () => {
    if (discoveryRequests.get(requestId) !== request) return;
    discoveryRequests.delete(requestId);
    await relayToApp({type:'discoverResult',requestId,canonicalUrl:request.url,candidates:[],error:'target tab unavailable'});
  });
}
async function startDiscovery(msg) {
  const url = validHttpUrl(msg.url || msg.canonicalUrl);
  const requestId = Number(msg.requestId);
  if (!url || !Number.isSafeInteger(requestId) || requestId <= 0 || discoveryRequests.has(requestId)) return;
  const existing=(await chrome.tabs.query({})).find(t=>t.url===url);
  const tab = existing || await chrome.tabs.create({url,active:false});
  discoveryRequests.set(requestId, {targetTabId:tab.id,url});
  void sendDiscoveryWhenReady(requestId);
}
async function scanAutoTab(tabId) {
  if (!autoMode || appTabId == null) return;
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch (_) { return; }
  if (isApprovedAppUrl(tab.url)) return;
  if (autoTargetTabId != null) await relayToTab(autoTargetTabId, {type:'cancelDiscovery'});
  for (const [id,r] of discoveryRequests) if (r.auto) discoveryRequests.delete(id);
  autoGeneration++;
  autoTargetTabId = null;
  await relayToApp({type:'autoCandidatesCleared',generation:autoGeneration});
  if (!autoMode || tab.incognito || !tab.active || !validHttpUrl(tab.url)) return;
  autoTargetTabId = tab.id;
  const requestId = 1_000_000_000 + autoGeneration;
  discoveryRequests.set(requestId, {targetTabId:tab.id,url:validHttpUrl(tab.url),auto:true,generation:autoGeneration});
  void sendDiscoveryWhenReady(requestId);
}
function scheduleAutoScan(tabId) {
  if (!autoMode || tabId == null) return;
  if (autoTimer !== null) clearTimeout(autoTimer);
  autoTimer = setTimeout(() => {autoTimer = null; enqueue(() => scanAutoTab(tabId));}, 450);
}

// Scope popup suppression to a visible room-gated picker, never unrelated browsing.
const pickerGuards=new Map();
async function blockPickerPopup(tab){
  const guard=pickerGuards.get(tab.openerTabId);
  if(tab.id!=null && guard && guard.until>Date.now() && activeRoom?.roomId===guard.roomId){
    await chrome.tabs.remove(tab.id).catch(()=>{});
  }
}
chrome.tabs.onCreated?.addListener(tab=>{void blockPickerPopup(tab);});

async function pageVideoCanPlayInRoom(url) {
  if(!/\.m3u8(?:$|#)/i.test(url))return {ok:true};
  // Probe in the actual room origin: extension fetch privileges do not prove browser CORS access.
  try {
    const results=await boundedRead(chrome.scripting.executeScript({target:{tabId:activeRoom.appTabId},world:'MAIN',args:[url],func:async mediaUrl=>{
      let response;
      try {
        response=await fetch(mediaUrl,{credentials:'omit',signal:AbortSignal.timeout(8000)});
        if(!response.ok)return {ok:false,reason:'http',status:response.status};
        const reader=response.body.getReader();let text='';
        try{while(text.length<1024){const {done,value}=await reader.read();if(done)break;text+=new TextDecoder().decode(value.subarray(0,1024-text.length));if(text.includes('#EXTM3U'))return {ok:true};}}
        finally{await reader.cancel();}
        return {ok:false,reason:'invalid-manifest'};
      }catch(error){return {ok:false,reason:['AbortError','TimeoutError'].includes(error?.name)?'timeout':'network'};}
      finally{if(response?.body && !response.body.locked)await response.body.cancel().catch(()=>{});}
    }}));
    return results[0]?.result || {ok:false,reason:'room-unavailable'};
  }catch(_){return {ok:false,reason:'room-unavailable'};}
}

async function beginPageHandoff(sourceTab,url) {
      await refreshActiveRoom();if(!activeRoom)return {ok:false};
      const capability=await boundedRead(chrome.scripting.executeScript({target:{tabId:activeRoom.appTabId},world:'MAIN',func:()=>({direct:window.__wp_direct_handoff===true,hls:!!window.Hls,page:window.__wp_page_handoff===true})}));
      if(!capability[0]?.result?.direct || (/\.m3u8(?:$|#)/i.test(url||'')&&!capability[0]?.result?.hls))return {ok:false,error:'Reload your WatchParty room once to enable page videos.'};
      const current=await chrome.tabs.get(sourceTab.id);
      if(current.url!==sourceTab.url)return {ok:false};
      const rows=await chrome.tabs.sendMessage(current.id,{from:'ext-bg',json:JSON.stringify({type:'getPageVideos'})});
      const candidate=rows?.find(c=>c.url===url && validHttpUrl(c.url) && (!new URL(c.url).search || c.mode==='page') && ((c.mode==='page'&&c.url===current.url) || /\.(mp4|webm|m4v|m3u8)(?:$|#)/i.test(c.url)||(/^https:\/\/hubstream\.art\/#[A-Za-z0-9]{1,100}$/.test(c.url)&&c.url===current.url)));
      if(!candidate)return {ok:false};
      if(candidate.mode==='page'&&!capability[0]?.result?.page)return {ok:false,error:'Reload your WatchParty room to enable page resolution.'};
      const check=candidate.mode==='page'?{ok:true}:await pageVideoCanPlayInRoom(candidate.url);
      if(!check.ok){
        const errors={
          http:'Video server returned HTTP '+check.status+'. Refresh the video page and try again.',
          'invalid-manifest':'This link returned a web page or invalid playlist, not a playable HLS stream.',
          timeout:'The video server did not respond within 8 seconds. Try again.',
          network:'WatchParty could not fetch this stream. It may be a network or browser cross-origin restriction.',
          'room-unavailable':'The WatchParty tab did not respond. Reload your room and try again.',
        };
        return {ok:false,error:(errors[check.reason]||'Could not check this video.')+' Your room has not changed.'};
      }
      const app=await openRoom();if(!activeRoom)return {ok:false};
      pendingHandoff={requestId:Date.now().toString(36)+'-'+(++requestSerial),createdAt:Date.now(),sourceTabId:current.id,sourceUrl:current.url,appTabId:app.id,mode:candidate.mode==='page'?'page':'direct',url:candidate.url,title:String(candidate.title||'Video').slice(0,200),position:Math.max(0,Math.min(Number(candidate.position)||0,86400))};
      appTabId=app.id;await save();await relayToTab(current.id,{type:'handoffStarted',requestId:pendingHandoff.requestId,url:pendingHandoff.url});await deliverHandoff();return {ok:true};
}

chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  const popup=message?.from==='popup' && sender.url===chrome.runtime.getURL('popup.html');
  const sourceCall=message?.from==='sourceCall' && message.type==='floatCall' && canonicalSource(sender.tab?.url);
  const sourceAction=message?.from==='sourceAction' && ['roomState','openRoom','handoff','floatCall'].includes(message.type) && canonicalSource(sender.tab?.url);
  const genericAction=message?.from==='genericAction' && ['roomState','handoff','protectPicker'].includes(message.type) && validHttpUrl(sender.tab?.url) && !isApprovedAppUrl(sender.tab?.url);
  if(!popup&&!sourceCall&&!sourceAction&&!genericAction)return;
  (async()=>{
    await ensureLoaded();
    if((sourceAction||genericAction) && message.type==='roomState'){await refreshActiveRoom();return {ok:true,room:activeRoom?.roomId||null};}
    if(genericAction && message.type==='protectPicker'){
      if(activeRoom && message.visible===true)pickerGuards.set(sender.tab.id,{roomId:activeRoom.roomId,until:Date.now()+10000});
      else pickerGuards.delete(sender.tab.id);
      return {ok:true};
    }
    if(genericAction && message.type==='handoff'){
      return beginPageHandoff(sender.tab,message.url);
    }
    if(sourceAction && message.type==='handoff'){await beginHandoff(sender.tab,message);return {ok:true};}
    if(message.type==='openRoom'){await openRoom();return {ok:true};}
    if(message.type==='floatCall'){
      // Cross-tab execution may lack the user gesture required for document PiP.
      // Bring the user to the room's real Float call button instead of retrying silently.
      if(await floatOwnedCall().catch(()=>false))return {ok:true};
      await openRoom();
      return {ok:true,openedRoom:true};
    }
    const [activeTab]=await chrome.tabs.query({active:true,currentWindow:true});
    const tab=popup&&sender.tab ? sender.tab : activeTab;
    let source=null;
    if(tab?.id!=null&&canonicalSource(tab.url))source=await chrome.tabs.sendMessage(tab.id,{from:'ext-bg',json:JSON.stringify({type:'getSource'})}).catch(()=>null);
    await refreshActiveRoom();
    if(popup && message.type==='pageHandoff' && tab?.id!=null && validHttpUrl(tab.url) && !isApprovedAppUrl(tab.url))return beginPageHandoff(tab,message.url);
    let videos=[];
    if(popup && message.type==='inspect' && tab?.id!=null && validHttpUrl(tab.url) && !isApprovedAppUrl(tab.url)){
      // Also works on tabs opened before the extension was installed or updated.
      await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content/urls.js','content/page-videos.js']}).catch(()=>{});
      const rows=await chrome.tabs.sendMessage(tab.id,{from:'ext-bg',json:JSON.stringify({type:'getPageVideos'})}).catch(()=>[]);
      videos=Array.isArray(rows)?rows.slice(0,12):[];
    }
    if(message.type==='handoff'&&source)await beginHandoff(tab,source);
    return {ok:message.type!=='handoff'||!!source,source,videos,room:activeRoom?.roomId||null};
  })().then(reply,()=>reply({ok:false}));
  return true;
});

const driveRangeRequests=new Map();
// Local Drive resolution must not change which room/source tab owns co-watch.
chrome.runtime.onMessage.addListener((message,sender)=>{
  if(message?.from!=='app'||!isApprovedAppUrl(sender.tab?.url)||typeof message.json!=='string'||message.json.length>2048)return;
  let payload;try{payload=JSON.parse(message.json);}catch(_){return;}
  if(!['resolveDrive','readDriveRange','resolveHubstream','readHubstreamResource'].includes(payload.type)||typeof payload.requestId!=='string'||payload.requestId.length>100)return;
  const tabId=sender.tab.id;
  if(payload.type==='readHubstreamResource'){
    WatchPartyHubstream.resource(payload.videoId,payload.url).catch(()=>({error:'Hubstream media could not load from its source page.'})).then(async result=>{
      const tab=await chrome.tabs.get(tabId).catch(()=>null);
      if(tab&&isApprovedAppUrl(tab.url))await chrome.tabs.sendMessage(tabId,{from:'ext',json:JSON.stringify({type:'hubstreamResource',requestId:payload.requestId,videoId:payload.videoId,...result})}).catch(()=>{});
    });return;
  }
  if(payload.type==='resolveHubstream'){
    WatchPartyHubstream.resolve(payload.videoId).then(body=>({body}),()=>({error:'Hubstream could not resolve this video in your browser. Open the source page and try again.'})).then(async result=>{
      const tab=await chrome.tabs.get(tabId).catch(()=>null);
      if(tab&&isApprovedAppUrl(tab.url))await chrome.tabs.sendMessage(tabId,{from:'ext',json:JSON.stringify({type:'hubstreamResolved',requestId:payload.requestId,videoId:payload.videoId,...result})}).catch(()=>{});
    });return;
  }
  if(payload.type==='readDriveRange'){
    if((driveRangeRequests.get(tabId)||0)>=4)return;
    driveRangeRequests.set(tabId,(driveRangeRequests.get(tabId)||0)+1);
    WatchPartyDrive.readOriginal(payload.fileId,payload.start,payload.length).then(result=>{
      let binary='';for(let i=0;i<result.bytes.length;i+=8192)binary+=String.fromCharCode(...result.bytes.subarray(i,i+8192));
      return {size:result.size,data:btoa(binary)};
    }).catch(()=>({error:'Original Drive file unavailable. Check access and try again.'})).then(async result=>{
      const tab=await chrome.tabs.get(tabId).catch(()=>null);
      if(tab&&isApprovedAppUrl(tab.url))await chrome.tabs.sendMessage(tabId,{from:'ext',json:JSON.stringify({type:'driveRange',requestId:payload.requestId,fileId:payload.fileId,start:payload.start,...result})}).catch(()=>{});
    }).finally(()=>{const count=(driveRangeRequests.get(tabId)||1)-1;if(count)driveRangeRequests.set(tabId,count);else driveRangeRequests.delete(tabId);});
    return;
  }
  WatchPartyDrive.resolve(payload.fileId).then(
    media=>({type:'driveResolved',requestId:payload.requestId,fileId:payload.fileId,...media}),
    ()=>({type:'driveResolved',requestId:payload.requestId,fileId:payload.fileId,error:'Drive preview unavailable. Check access to this file and try again.'})
  ).then(async result=>{
    const tab=await chrome.tabs.get(tabId).catch(()=>null);
    if(tab&&isApprovedAppUrl(tab.url))await chrome.tabs.sendMessage(tabId,{from:'ext',json:JSON.stringify(result)}).catch(()=>{});
  });
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (!message || typeof message.json !== 'string' || message.json.length > 256_000 || sender.tab?.id == null) return;
  let payload;
  try { payload = JSON.parse(message.json); } catch (_) { return; }
  if (!payload || typeof payload !== 'object') return;
  enqueue(async () => {
    if (message.from === 'handoff') {
      const source=await chrome.tabs.get(sender.tab.id);
      if(payload.type==='handoff') await beginHandoff(source,payload);
      return;
    }
    if (message.from === 'app') {
      if (!isApprovedAppUrl(sender.tab.url) || message.json.length > 32_000) return;
      const current = await chrome.tabs.get(sender.tab.id);
      if (!isApprovedAppUrl(current.url)) return;
      if (payload.type === 'resolveDrive' || payload.type === 'readDriveRange' || payload.type === 'resolveHubstream' || payload.type === 'readHubstreamResource') return;
      if (payload.type === 'handoffResult') { await finishHandoff(payload,current); return; }
      if (payload.type === 'roomStatus') {
        if (activeRoom && activeRoom.appTabId !== current.id) return;
        activeRoom=payload.roomId ? {appTabId:current.id,roomId:payload.roomId,isHost:!!payload.isHost} : null;
        if(activeRoom) appTabId=current.id; else await WatchPartyHubstream.closeOwned();
        await save(); await deliverHandoff(); return;
      }
      if ((payload.type==='ping'||payload.type==='hello') && pendingHandoff?.appTabId===current.id) await deliverHandoff();
      if (appTabId != null && appTabId !== current.id) return;
      if (payload.type === 'hello' || payload.type === 'ping') return;
      if (appTabId == null) {
        if (!['open','discover','autoDiscover'].includes(payload.type) || (payload.type === 'autoDiscover' && !payload.enabled)) return;
        appTabId = current.id;
        await save();
      }
      if (payload.type === 'close') { await closeSession(); }
      else if (payload.type === 'open') { await openOrFocus(payload.url); }
      else if (payload.type === 'discover') { await startDiscovery(payload); }
      else if (payload.type === 'autoDiscover') {
        await stopDiscovery();
        autoMode = !!payload.enabled;
        await relayToApp({type:'autoCandidatesCleared',generation:autoGeneration});
        if (autoMode) {
          const tabs = await chrome.tabs.query({active:true,lastFocusedWindow:true});
          if (tabs[0]?.id != null) scheduleAutoScan(tabs[0].id);
        }
      } else if (['command','state'].includes(payload.type) && streamTabId != null) {
        await relayToTab(streamTabId, payload);
      }
      return;
    }
    if (message.from === 'discovery') {
      const requestId = Number(payload.requestId);
      const request = discoveryRequests.get(requestId);
      if (!request || request.targetTabId !== sender.tab.id || validHttpUrl(payload.canonicalUrl) !== request.url) return;
      const tab = await chrome.tabs.get(sender.tab.id);
      if (validHttpUrl(tab.url) !== request.url) return;
      discoveryRequests.delete(requestId);
      if (request.auto && (!autoMode || request.generation !== autoGeneration || tab.id !== autoTargetTabId)) return;
      // Explicit resolution may return a device-local media URL to the approved app.
      // Automatic suggestions still carry only public page identities.
      const candidates = (Array.isArray(payload.candidates) ? payload.candidates : []).slice(0,24).map(c => ({
        key: String(c.key || '').slice(0,100),
        url: (!request.auto && WatchPartyUrls.localMedia(c.localUrl)) || (c.portable && validHttpUrl(c.url) ? c.url : request.url),
        canonicalUrl: request.url, title: String(c.title || '').slice(0,500),
        thumbnail:'', format:String(c.format || '').slice(0,16), source:String(c.source || '').slice(0,32),
        referer:new URL(request.url).origin, duration:'', isPrimary:!!c.isPrimary,
        portable: !!c.portable && !!validHttpUrl(c.url),
      }));
      if (request.auto) {
        await relayToApp({type:'autoCandidates',generation:request.generation,tabId:tab.id,canonicalUrl:request.url,pageTitle:candidates[0]?.title || '',candidates});
      } else await relayToApp({type:'discoverResult',requestId,canonicalUrl:request.url,candidates});
      return;
    }
    if (message.from === 'sync' && (sender.tab.id === streamTabId || sender.tab.id === autoTargetTabId) && appTabId != null) {
      if (payload.type === 'openRoom') { await openRoom(); return; }
      if (payload.type === 'disconnect') {
        await relayToApp({type:'tabClosed'});
        await closeSession();
        return;
      }
      if (sender.tab.id !== streamTabId) return;
      if (payload.type === 'attached') { await activateStream(); return; }
      if (!['event','ready'].includes(payload.type)) return;
      const tab = await chrome.tabs.get(streamTabId);
      const url = validHttpUrl(payload.url);
      if (!validHttpUrl(tab.url) || new URL(tab.url).origin !== streamOrigin) { await closeSession(); return; }
      // Navigation can race a final event from the previous document. Drop it.
      if (!url || url !== validHttpUrl(tab.url)) return;
      await relayToApp({type:payload.type,action:payload.action,url,title:String(payload.title || '').slice(0,500),
        position:payload.position,duration:payload.duration,playing:!!payload.playing,ts:payload.ts});
    }
  });
});
chrome.tabs.onActivated.addListener(({tabId}) => scheduleAutoScan(tabId));
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => enqueue(async () => {
  if (activeRoom?.appTabId === tabId && changeInfo.status === 'loading') { activeRoom=null; await save(); }
  if (pendingHandoff?.sourceTabId === tabId && changeInfo.url && canonicalSource(tab.url)!==pendingHandoff.url) { pendingHandoff=null; await save(); }
  if (tabId === appTabId && changeInfo.status === 'loading') { await closeSession(); return; }
  if (tabId === appTabId && !isApprovedAppUrl(tab.url)) { await closeSession(); return; }
  if (tabId === streamTabId) {
    if (!isLinkedSource(tab)) { await closeSession(); return; }
    if (changeInfo.status === 'complete') await activateStream();
  }
  if (autoMode && tab.active && (changeInfo.status === 'complete' || changeInfo.url)) scheduleAutoScan(tabId);
}));
chrome.tabs.onRemoved.addListener(tabId => enqueue(async () => {
  if(activeRoom?.appTabId===tabId){activeRoom=null;await WatchPartyHubstream.closeOwned();}
  if(pendingHandoff && [pendingHandoff.appTabId,pendingHandoff.sourceTabId].includes(tabId))pendingHandoff=null;
  await save();
  if (tabId === appTabId) { await closeSession(); return; }
  for (const [id,r] of discoveryRequests) if (r.targetTabId === tabId) discoveryRequests.delete(id);
  if (tabId === autoTargetTabId) autoTargetTabId = null;
  if (tabId === streamTabId) {
    streamTabId = null; streamOrigin = null; await save();
    await relayToApp({type:'tabClosed'});
  }
}));
