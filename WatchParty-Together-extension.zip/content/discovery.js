/* WatchParty request-triggered generic video discovery.
 * Dormant until the app asks for a bounded scan; it never watches pages by default.
 */
(function () {
  'use strict';
  if (window.__wpExtDiscovery) return;
  window.__wpExtDiscovery = true;

  var MAX_CANDIDATES = 24;
  var MAX_MUTATIONS = 8;
  var SCAN_WINDOW_MS = 700;
  var timer = null;
  var observer = null;
  var activeRequest = null;
  var generation = 0;

  var MEDIA_EXTENSIONS = /\.(?:mp4|m4v|webm|mov|mkv|avi|m3u8|mpd)(?:$|[?#])/i;
  var SEGMENT_EXTENSIONS = /\.(?:ts|m4s|cmfv|cmfa|ismv|isma|aac|vtt)(?:$|[?#])/i;
  var TRACKER_WORDS = /(?:^|[.\/_-])(?:ad|ads|advert|advertisement|doubleclick|googlesyndication|analytics|tracker|tracking|pixel|telemetry)(?:[.\/_-]|$)/i;
  var SEGMENT_WORDS = /(?:^|[.\/_-])(?:segment|seg|chunk|fragment|part|init)(?:[.\/_=-]|$)/i;
  var KNOWN_EMBED = /(?:youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com|twitch\.tv|soundcloud\.com|facebook\.com|twitter\.com|x\.com|player\.vimeo\.com)/i;
  var URL_KEYS = /^(?:contentUrl|embedUrl|video|videoUrl|streamUrl|playbackUrl|src|url)$/i;

  function asUrl(value) {
    if (typeof value !== 'string' || !value.trim()) return null;
    try {
      var url = new URL(value.trim(), location.href);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
      return url.href;
    } catch (e) { return null; }
  }

  function isRejected(url) {
    if (!url || /^(?:blob:|data:)/i.test(url)) return true;
    try {
      var parsed = new URL(url);
      var text = (parsed.hostname + parsed.pathname + parsed.search).toLowerCase();
      if (TRACKER_WORDS.test(text)) return true;
      if (SEGMENT_EXTENSIONS.test(parsed.pathname) || SEGMENT_WORDS.test(text)) return true;
      if (/[?&](?:segment|seg|chunk|fragment|part|range|offset)=/i.test(parsed.search)) return true;
      return false;
    } catch (e) { return true; }
  }

  var VOLATILE_QUERY_KEY = /^(?:expires?|exp|signature|sig|token|auth|authorization|x-amz-|awsaccesskeyid|key-pair-id|policy|hdntl|hmac|hash|verify|validuntil|e|st|px)\b/i;

  function canonicalCandidateUrl(raw) {
    var parsed = new URL(raw);
    var kept = [];
    parsed.searchParams.forEach(function (value, key) {
      if (!VOLATILE_QUERY_KEY.test(key)) kept.push([key, value]);
    });
    kept.sort(function (a, b) { return a[0].localeCompare(b[0]) || a[1].localeCompare(b[1]); });
    parsed.search = '';
    kept.forEach(function (pair) { parsed.searchParams.append(pair[0], pair[1]); });
    return parsed.origin + parsed.pathname + (parsed.search || '') + parsed.hash;
  }

  function bytesToHex(bytes) {
    return Array.from(bytes).map(function (byte) { return byte.toString(16).padStart(2, '0'); }).join('');
  }

  async function candidateKey(url) {
    var identity = canonicalCandidateUrl(url);
    var digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(identity));
    return 'c_' + bytesToHex(new Uint8Array(digest)).slice(0, 24);
  }

  function isPortable(url, kind) {
    if (!WatchPartyUrls.shareable(url)) return false;
    if (kind === 'embed') return true;
    if (!MEDIA_EXTENSIONS.test(url)) return false;
    try {
      var parsed = new URL(url);
      return !parsed.username && !parsed.password && !parsed.search;
    } catch (e) { return false; }
  }

  function addCandidate(list, seen, value, kind) {
    var url = asUrl(value);
    if (!url || isRejected(url) || list.length >= MAX_CANDIDATES) return;
    var identity = canonicalCandidateUrl(url);
    if (seen[identity]) return;
    seen[identity] = true;
    list.push({
      url: url,
      kind: kind || (MEDIA_EXTENSIONS.test(url) ? 'direct' : 'unknown'),
      portable: isPortable(url, kind),
    });
  }

  function attr(node, name) {
    try { return node.getAttribute(name) || ''; } catch (e) { return ''; }
  }

  function scanJson(value, list, seen, depth, urlContext) {
    if (depth > 4 || list.length >= MAX_CANDIDATES || value == null) return;
    if (typeof value === 'string') {
      if (urlContext) addCandidate(list, seen, value, urlContext);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach(function (item) { scanJson(item, list, seen, depth + 1, urlContext); });
      return;
    }
    if (typeof value !== 'object') return;
    Object.keys(value).forEach(function (key) {
      var item = value[key];
      if (URL_KEYS.test(key)) {
        var kind = key.toLowerCase() === 'embedurl' ? 'embed' : 'jsonld';
        scanJson(item, list, seen, depth + 1, kind);
      } else if (typeof item === 'object') scanJson(item, list, seen, depth + 1, urlContext);
    });
  }

  // Mobile PackedJs parity: string substitution only, never eval website code.
  function unpackMedia(script) {
    if (!script || script.length > 512000 || !script.includes('.split(')) return [];
    var blocks = /\}\s*\(\s*'((?:\\.|[^'\\])*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:\\.|[^'\\])*)'\s*\.split\('\|'\)/g;
    var urls = [], match, processed = 0;
    while ((match = blocks.exec(script)) && processed++ < 8) {
      var radix = Number(match[2]), count = Number(match[3]);
      if (radix < 2 || radix > 36 || count < 1 || count > 200000) continue;
      var words = match[4].split('|'), dict = Object.create(null);
      for (var i = 0; i < Math.min(count, words.length); i++) if (words[i]) dict[i.toString(radix)] = words[i];
      var decoded = match[1].replace(/\b\w+\b/g, function(word) { return dict[word] || word; })
        .replace(/\\\//g, '/').replace(/\\u([0-9a-f]{4})/gi, function(_, hex) { return String.fromCharCode(parseInt(hex, 16)); });
      var media = decoded.match(/https?:\/\/[^"'\\\s<>]+?\.(?:m3u8|mp4)[^"'\\\s<>]*/gi) || [];
      urls.push.apply(urls, media.slice(0, MAX_CANDIDATES));
    }
    return urls.slice(0, MAX_CANDIDATES);
  }

  function scan() {
    var list = [];
    var seen = Object.create(null);
    var adUrls = new Set();
    var media = document.querySelectorAll('video, audio');
    for (var i = 0; i < media.length; i++) {
      var node = media[i], values = [node.currentSrc, node.src, attr(node, 'src')];
      var adMarked = attr(node, 'data-ad') === 'true' || /(?:^|[\s_-])(?:ad|ads|advertisement)(?:[\s_-]|$)/i.test(attr(node, 'class') + ' ' + attr(node, 'aria-label'));
      for (var v = 0; v < values.length; v++) {
        var mediaUrl = asUrl(values[v]);
        if (adMarked) { if (mediaUrl) adUrls.add(mediaUrl); continue; }
        addCandidate(list, seen, values[v], 'direct');
        var candidate = list.find(function(c) { return c.url === mediaUrl; });
        if (candidate) {
          candidate.seconds = Number.isFinite(node.duration) && node.duration > 0 ? node.duration : 0;
          candidate.thumbnail = WatchPartyUrls.shareable(asUrl(node.poster || attr(node, 'poster'))) || '';
          candidate.title = attr(node, 'title') || attr(node, 'aria-label') || '';
        }
      }
    }
    var sources = document.querySelectorAll('video source, audio source');
    for (var j = 0; j < sources.length; j++) addCandidate(list, seen, sources[j].src || attr(sources[j], 'src'), 'direct');

    var frames = document.querySelectorAll('iframe');
    for (var k = 0; k < frames.length; k++) {
      var frameUrl = asUrl(frames[k].src || attr(frames[k], 'src'));
      if (frameUrl && KNOWN_EMBED.test(frameUrl)) addCandidate(list, seen, frameUrl, 'embed');
    }

    var metas = document.querySelectorAll('meta[property], meta[name]');
    for (var m = 0; m < metas.length; m++) {
      var key = (attr(metas[m], 'property') || attr(metas[m], 'name')).toLowerCase();
      if (/^(?:og|twitter):video(?::secure_url|:url|:iframe)?$/.test(key)) addCandidate(list, seen, attr(metas[m], 'content'), key.indexOf('iframe') >= 0 ? 'embed' : 'meta');
    }

    var jsonScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (var n = 0; n < jsonScripts.length; n++) {
      try { scanJson(JSON.parse(jsonScripts[n].textContent || ''), list, seen, 0); } catch (e) {}
    }

    var scripts = document.querySelectorAll('script:not([src])');
    for (var si = 0; si < Math.min(scripts.length, 64); si++) {
      unpackMedia(scripts[si].textContent || '').forEach(function(url) { addCandidate(list, seen, url, 'packed-script'); });
    }

    var resources = [];
    try { resources = performance.getEntriesByType('resource') || []; } catch (e) {}
    for (var r = 0; r < resources.length; r++) {
      var resourceUrl = asUrl(resources[r].name);
      if (resourceUrl && (MEDIA_EXTENSIONS.test(resourceUrl) || KNOWN_EMBED.test(resourceUrl))) {
        addCandidate(list, seen, resourceUrl, KNOWN_EMBED.test(resourceUrl) ? 'embed' : 'resource');
      }
    }
    return list.filter(function(c) { return !adUrls.has(c.url); })
      .sort(function(a,b) { return (b.seconds || 0) - (a.seconds || 0); });
  }

  function durationLabel(seconds) {
    if (!seconds) return '';
    var n = Math.floor(seconds), h = Math.floor(n / 3600), m = Math.floor(n % 3600 / 60), sec = String(n % 60).padStart(2, '0');
    return h ? h + ':' + String(m).padStart(2, '0') + ':' + sec : m + ':' + sec;
  }

  function canonicalUrl(requestCanonical) {
    var requested = asUrl(requestCanonical);
    if (requested) return requested;
    var links = document.querySelectorAll('link[rel="canonical"]');
    if (links.length) {
      var linked = asUrl(links[0].href || attr(links[0], 'href'));
      if (linked) return linked;
    }
    return asUrl(location.href) || '';
  }

  async function finish(request) {
    if (!activeRequest || activeRequest !== request) return;
    activeRequest = null;
    if (timer) { clearTimeout(timer); timer = null; }
    if (observer) { observer.disconnect(); observer = null; }
    var canonical = WatchPartyUrls.shareable(canonicalUrl(request.canonicalUrl));
    if (!canonical || !WatchPartyUrls.shareable(location.href)) return;
    var rawCandidates = scan();
    if(request.localPlayback){
      const signed=rawCandidates.filter(c=>!c.portable && WatchPartyUrls.localMedia(c.url));
      // A single signed source outranks stale unsigned resource-timing entries.
      if(signed.length===1)rawCandidates=signed;
    }
    var candidates = await Promise.all(rawCandidates.map(async function (candidate, index) {
      return {
        key: await candidateKey(candidate.url),
        localUrl: request.localPlayback ? WatchPartyUrls.localMedia(candidate.url) : undefined,
        // Nonportable media is played in this page with the user's own session.
        url: candidate.portable ? candidate.url : canonical,
        canonicalUrl: canonical,
        title: candidate.title || document.title || '',
        thumbnail: candidate.thumbnail || '',
        displayUrl: candidate.portable ? candidate.url : new URL(candidate.url).origin + new URL(candidate.url).pathname,
        format: MEDIA_EXTENSIONS.test(candidate.url) ? candidate.url.split(/[?#]/)[0].split('.').pop().toUpperCase() : '',
        source: candidate.kind,
        referer: location.origin,
        duration: durationLabel(candidate.seconds),
        isPrimary: index === 0,
        portable: candidate.portable,
      };
    }));
    if (request.generation !== generation) return;
    try {
      chrome.runtime.sendMessage({ from: 'discovery', json: JSON.stringify({
        type: 'discoverResult',
        requestId: request.requestId,
        canonicalUrl: canonical,
        candidates: candidates,
      }) });
    } catch (e) {}
  }

  function cancel() {
    generation++;
    activeRequest = null;
    if (timer) clearTimeout(timer);
    timer = null;
    if (observer) observer.disconnect();
    observer = null;
  }

  function discover(message) {
    cancel();
    if (!WatchPartyUrls.shareable(location.href)) return;
    var request = {
      requestId: Number.isSafeInteger(Number(message.requestId)) && Number(message.requestId) > 0 ? Number(message.requestId) : Date.now(),
      canonicalUrl: message.canonicalUrl,
      mutations: 0,
      localPlayback: message.localPlayback === true,
      generation: generation,
    };
    activeRequest = request;
    // A short observer window catches player sources inserted after route changes without turning this into a page watcher.
    try {
      observer = new MutationObserver(function () {
        if (!activeRequest || activeRequest !== request || ++request.mutations > MAX_MUTATIONS) return;
      });
      observer.observe(document.documentElement || document, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    } catch (e) {}
    timer = setTimeout(function () { void finish(request); }, SCAN_WINDOW_MS);
  }

  chrome.runtime.onMessage.addListener(function (message) {
    if (!message || message.from !== 'ext-bg' || typeof message.json !== 'string') return;
    var payload;
    try { payload = JSON.parse(message.json); } catch (e) { return; }
    if (payload.type === 'discover') discover(payload);
    else if (payload.type === 'cancelDiscovery' || payload.type === 'close') cancel();
  });
})();
