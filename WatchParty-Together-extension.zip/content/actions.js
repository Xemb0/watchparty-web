/* Explicit, user-initiated provider handoff. No playback observation before click. */
(() => {
  if (window.__wpActions) return;
  window.__wpActions = true;
  let pending = null, action = null, callAction = null, roomId = null, disconnected = false;
  function source() {
    const u = new URL(location.href), h = u.hostname;
    const youtube = ['youtube.com','www.youtube.com','m.youtube.com'].includes(h) && u.pathname === '/watch' && /^[\w-]{11}$/.test(u.searchParams.get('v') || '');
    const provider = ((h === 'netflix.com' || h.endsWith('.netflix.com')) && /^\/watch\/\d+/.test(u.pathname)) ||
      ((h === 'primevideo.com' || h.endsWith('.primevideo.com')) && /\/(detail|gp\/video|watch)\//.test(u.pathname));
    if (!youtube && !provider) return null;
    if (!WatchPartyUrls.shareable(u.href)) return null;
    return {url:youtube ? 'https://www.youtube.com/watch?v='+u.searchParams.get('v') : u.origin+u.pathname, mode:youtube?'embed':'provider'};
  }
  function snapshot() {
    const s=source(); if(!s) return null;
    const videos=[...document.querySelectorAll('video')];
    const v=videos.find(v=>!v.paused&&!v.ended)||videos.find(v=>v.duration>0)||videos[0];
    return {...s,title:document.title.replace(/\s[-–|]\sYouTube.*$/,''),position:v?.currentTime||0};
  }
  function renderRoom() {
    if (!action) return;
    const label=disconnected?'Refresh page to reconnect':roomId?(source()?.mode==='embed'?'Play in room':'Watch together'):'Open WatchParty';
    if(action.textContent!==label)action.textContent=label;
    action.hidden=!roomId;
    if(callAction)callAction.hidden=!roomId||disconnected;
  }
  async function send(payload) {
    try {
      const result=await chrome.runtime.sendMessage({from:'sourceAction',...payload});
      if(!result?.ok)throw Error('Extension unavailable');
      return result;
    } catch (_) { disconnected=true;renderRoom();return null; }
  }
  async function refreshRoom() {
    if(disconnected||document.hidden)return;
    const result=await send({type:'roomState'});
    if(result){roomId=result.room;renderRoom();}
  }
  async function start(mode) {
    if(disconnected){location.reload();return;}
    const s=snapshot(); if(!s)return;
    await send(roomId?{type:'handoff',...s,mode:mode||s.mode}:{type:'openRoom'});
  }
  function mount() {
    const s=source();
    if(!s){action?.remove();callAction?.remove();action=null;callAction=null;return;}
    if(action?.isConnected)return;
    const target=s.mode==='embed' ? document.querySelector('ytd-watch-metadata #top-level-buttons-computed, ytd-watch-metadata #actions') : document.body;
    if(!target)return;
    action=document.createElement('button'); action.type='button'; action.textContent=s.mode==='embed'?'Play in room':'Watch together';
    action.title='WatchParty'; action.style.cssText='border:0;border-radius:22px;padding:10px 16px;background:#8b5cf6;color:#fff;font:600 14px system-ui;cursor:pointer;white-space:nowrap;margin:0 8px;';
    if(s.mode==='provider')action.style.cssText+='position:fixed;top:64px;right:16px;z-index:2147483646;box-shadow:0 3px 16px #0007;';
    action.onclick=()=>start(); target.appendChild(action);
    callAction=document.createElement('button');callAction.type='button';callAction.textContent='Show call';callAction.style.cssText=action.style.cssText;
    if(s.mode==='provider')callAction.style.cssText+='top:110px;';
    callAction.onclick=()=>send({type:'floatCall'});
    target.appendChild(callAction);
    renderRoom();
  }
  chrome.runtime.onMessage.addListener((m,_sender,reply)=>{
    if(m?.from!=='ext-bg')return;
    let p;try{p=JSON.parse(m.json)}catch(_){return;}
    if(p.type==='roomStatus'){roomId=p.roomId||null;renderRoom();return;}
    if(p.type==='getSource'){reply(snapshot());return;}
    if(p.type==='handoffStarted')pending={requestId:p.requestId,url:p.url};
    if(p.type==='handoffComplete'&&pending&&p.requestId===pending.requestId&&p.url===pending.url&&source()?.url===pending.url){
      // The room reported this exact embedded video actually playing.
      const videos=[...document.querySelectorAll('video')];
      videos.forEach(v=>v.pause());
      const paused=videos.length>0&&videos.every(v=>v.paused);
      if(paused)pending=null;reply({paused});
    }
  });
  let scheduled=false;
  new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;mount();});}).observe(document.documentElement,{childList:true,subtree:true});
  mount();
  refreshRoom();
  window.addEventListener('focus',refreshRoom);
  setInterval(refreshRoom,5000);
})();
