/* Room-gated public video actions. Never exports session-bound media URLs. */
(() => {
  if(window.__wpPageVideos)return;window.__wpPageVideos=true;
  if(WatchPartyUrls.approvedApp(location.href)||!WatchPartyUrls.shareable(location.href))return;
  // These pages already have their provider-specific actions.
  const h=location.hostname;
  if(/(^|\.)(youtube\.com|netflix\.com|primevideo\.com)$/.test(h))return;
  let root=null,room=null,pending=null,busy=false,dead=false,dismissed=false,position=null;
  const candidateVideos=new Map();
  const previewFrames=new WeakMap();
  function metadata(v) {
    let thumbnail='';
    const poster=v?.poster || v?.getAttribute('poster');
    try { if(poster) thumbnail=WatchPartyUrls.shareable(new URL(poster,location.href).href)||''; } catch(_) {}
    if(!thumbnail && v){
      const cached=previewFrames.get(v);
      if(cached?.src===(v.currentSrc||v.src)) thumbnail=cached.image;
      else if(v.readyState>=2 && v.videoWidth>0){
        try {
          const canvas=document.createElement('canvas');canvas.width=240;canvas.height=Math.max(1,Math.round(240*v.videoHeight/v.videoWidth));
          canvas.getContext('2d').drawImage(v,0,0,canvas.width,canvas.height);
          thumbnail=canvas.toDataURL('image/jpeg',0.7);
          previewFrames.set(v,{src:v.currentSrc||v.src,image:thumbnail});
        } catch(_) { /* Cross-origin video pixels may be unavailable. */ }
      }
      if(!thumbnail && document.querySelectorAll('video').length===1){
        const og=document.querySelector?.('meta[property="og:image"]')?.content;
        try { if(og)thumbnail=WatchPartyUrls.shareable(new URL(og,location.href).href)||''; } catch(_) {}
      }
    }
    const seconds=v?.duration;
    let duration='Duration unavailable';
    if(seconds===Infinity) duration='Live';
    else if(Number.isFinite(seconds)&&seconds>0){
      const n=Math.floor(seconds),h=Math.floor(n/3600),m=Math.floor(n/60)%60;
      duration=(h?h+':'+String(m).padStart(2,'0'):String(m))+':'+String(n%60).padStart(2,'0');
    }
    return {thumbnail,duration};
  }
  function candidates(){
    const seen=new Set(),rows=[],videos=[...document.querySelectorAll('video')];candidateVideos.clear();
    if(/^https:\/\/hubstream\.art\/#([A-Za-z0-9]{1,100})$/.test(location.href)&&videos.some(v=>!v.mediaKeys)){
      const video=videos.find(v=>!v.mediaKeys);candidateVideos.set(location.href,video);
      return [{url:location.href,title:document.title||'Hubstream video',position:video.currentTime||0,...metadata(video)}];
    }
    function add(raw,v,title){
      const url=WatchPartyUrls.shareable(raw);if(!url)return;
      const u=new URL(url);
      if(u.protocol!=='https:'||u.search||! /\.(mp4|webm|m4v|m3u8)$/i.test(u.pathname)||seen.has(url)||v?.mediaKeys)return;
      seen.add(url);candidateVideos.set(url,v);rows.push({url,title,position:v?.currentTime||0,...metadata(v)});
    }
    videos.forEach((v,i)=>add(v.currentSrc||v.src||v.querySelector('source')?.src,v,v.title||v.getAttribute('aria-label')||('Video '+(i+1))));
    // MSE players expose blob: on <video>; the HTTP manifest remains in resource timing.
    const blobs=videos.filter(v=>!v.mediaKeys && (v.currentSrc||v.src||'').startsWith('blob:'));
    if(blobs.length===1){
      const resources=performance.getEntriesByType('resource').slice(-250);
      // Resource timing does not identify the active MSE manifest. Resolve the
      // page on each viewer instead of sharing a stale or session-bound URL.
      if(resources.some(r=>/\.m3u8(?:$|[?#])/i.test(r.name) && !/(?:doubleclick|googlesyndication|\/ads?\/)/i.test(r.name))){
        const page=WatchPartyUrls.shareable(location.href);
        if(page){candidateVideos.set(page,blobs[0]);return [{url:page,mode:'page',title:document.title||'Video',position:blobs[0].currentTime||0,...metadata(blobs[0])}];}
      }
      for(const r of resources)if(/\.m3u8(?:$|[?#])/i.test(r.name) && !/(?:doubleclick|googlesyndication|\/ads?\/)/i.test(r.name))add(r.name,blobs[0],'Stream '+(rows.length+1));
    }
    return rows.slice(0,12);
  }
  function clear(){root?.remove();root=null;}
  function render(){
    if(!room){clear();return;}
    if(dismissed)return;
    const rows=candidates();
    if(!rows.length && !document.querySelectorAll('video').length){clear();return;}
    const key=JSON.stringify(rows.map(({position,...row})=>row));
    if(root?.dataset.key===key)return;
    clear();
    // Clicks inside an extension-origin frame never bubble to the site's ad handlers.
    root=document.createElement('aside');root.dataset.key=key;
    root.style.cssText='position:fixed;inset:auto 16px 24px auto;margin:0;border:0;padding:0;z-index:2147483647;border-radius:16px;overflow:hidden;background:#140f22';
    const frame=document.createElement('iframe');frame.src=chrome.runtime.getURL('popup.html');
    frame.title='WatchParty videos';frame.style.cssText='display:block;width:320px;height:440px;max-height:60vh;border:0';
    if(position)Object.assign(root.style,{left:position.x+'px',top:position.y+'px',right:'auto',bottom:'auto'});
    root.append(frame);root.setAttribute('popover','manual');document.body.append(root);
    try{root.showPopover?.();}catch(_){}
  }
  window.addEventListener('message',e=>{
    const frame=root?.children[0];
    if(!frame || e.source!==frame.contentWindow || e.origin!==chrome.runtime.getURL('').replace(/\/$/,''))return;
    if(e.data?.wpPicker==='close'){
      dismissed=true;clear();
      chrome.runtime.sendMessage({from:'genericAction',type:'protectPicker',visible:false}).catch(()=>{});
    }else if(e.data?.wpPicker==='move' && Number.isFinite(e.data.dx) && Number.isFinite(e.data.dy)){
      const box=root.getBoundingClientRect();
      position={x:Math.max(0,Math.min(window.innerWidth-box.width,box.left+e.data.dx)),y:Math.max(0,Math.min(window.innerHeight-48,box.top+e.data.dy))};
      Object.assign(root.style,{left:position.x+'px',top:position.y+'px',right:'auto',bottom:'auto'});
    }
  });
  async function refresh(){
    if(document.hidden||busy||dead)return;busy=true;
    try{const r=await chrome.runtime.sendMessage({from:'genericAction',type:'roomState'});room=r?.ok?r.room:null;render();await chrome.runtime.sendMessage({from:'genericAction',type:'protectPicker',visible:!!root});}
    catch(_){dead=true;clear();}finally{busy=false;}
  }
  chrome.runtime.onMessage.addListener((m,_s,reply)=>{
    if(m?.from!=='ext-bg')return;let p;try{p=JSON.parse(m.json);}catch(_){return;}
    if(p.type==='getPageVideos'){reply(candidates());return;}
    if(p.type==='handoffStarted'){const v=candidateVideos.get(p.url);pending={...p,video:v,src:v?.currentSrc||v?.src};}
    if(p.type==='handoffComplete'&&pending?.requestId===p.requestId&&pending.url===p.url){
      const matches=pending.video && (pending.video.currentSrc||pending.video.src)===pending.src ? [pending.video] : [];matches.forEach(v=>v.pause());reply({paused:matches.length>0&&matches.every(v=>v.paused)});return;
    }
  });
  document.addEventListener?.('loadedmetadata',refresh,true);
  document.addEventListener?.('durationchange',refresh,true);
  setInterval(refresh,3000);window.addEventListener('focus',refresh);refresh();
})();
