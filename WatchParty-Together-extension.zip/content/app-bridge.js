/*
 * WatchParty Together — app-tab bridge.
 *
 * Runs on app.watchparty.online (and localhost dev) at document_start.
 * Relays window.postMessage ⇄ chrome.runtime so the Kotlin/Wasm app can talk
 * to the extension without knowing anything about chrome.* APIs:
 *
 *   page  → {wpExt:"app", json:"<json>"}  → service worker
 *   sw    → {from:"ext",  json:"<json>"}  → page as {wpExt:"ext", json}
 *
 * Announces itself immediately (pong) so the app can detect the extension
 * without a round trip; also answers explicit pings.
 */

function pong() {
  let version = "0";
  try { version = chrome.runtime.getManifest().version; } catch (e) {}
  window.postMessage(
    { wpExt: "ext", json: JSON.stringify({ type: "pong", version }) },
    "*",
  );
}

window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data || e.data.wpExt !== "app") return;
  const json = e.data.json;
  if (typeof json !== "string") return;
  let type = "";
  try { type = JSON.parse(json).type || ""; } catch (err) {}
  if (type === "ping") { pong(); }
  // Everything (including ping — it doubles as "app tab is here") goes to the
  // worker so it can (re)learn this tab's id.
  try { chrome.runtime.sendMessage({ from: "app", json }); } catch (err) {}
});

chrome.runtime.onMessage.addListener((m) => {
  if (m && m.from === "ext" && typeof m.json === "string") {
    window.postMessage({ wpExt: "ext", json: m.json }, "*");
  }
});

// Presence beacon: page scripts that loaded before us still detect the
// extension, and the worker learns our tab id up front.
pong();
try { chrome.runtime.sendMessage({ from: "app", json: JSON.stringify({ type: "hello" }) }); } catch (e) {}
