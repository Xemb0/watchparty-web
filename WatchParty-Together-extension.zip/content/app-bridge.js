/*
 * WatchParty Together — app-tab bridge.
 *
 * Runs on app.watchparty.online (and localhost dev) at document_start.
 * Relays window.postMessage ⇄ chrome.runtime so the Kotlin/Wasm app can talk
 * to the extension without knowing anything about chrome.* APIs:
 *
 *   page  → {wpExt:"app", json:"<json>"}  → service worker
 *   sw    → {from:"ext",  json:"<json>"}  → page as {wpExt:"ext", json}
 *
 * Announces itself immediately (pong) so the app can detect the extension
 * without a round trip; also answers explicit pings.
 */


function pong() {
  // Page-visible availability beacon consumed by HostedPageResolver.
  try { window.__wp_ext_available = true; } catch (e) {}
  let version = "0";
  try { version = chrome.runtime.getManifest().version; } catch (e) {}
  window.postMessage(
    { wpExt: "ext", json: JSON.stringify({ type: "pong", version }) },
    location.origin,
  );
}

window.addEventListener("message", (e) => {
  if (!WatchPartyUrls.approvedApp(location.href) || e.origin !== location.origin || e.source !== window || !e.data || e.data.wpExt !== "app") return;
  const json = e.data.json;
  if (typeof json !== "string") return;
  let message;
  try { message = JSON.parse(json); } catch (err) { return; }
  let type = message.type || "";
  if (type === "ping") { pong(); }
  try { chrome.runtime.sendMessage({ from: "app", json }); } catch (err) {}
});

chrome.runtime.onMessage.addListener((m,_sender,reply) => {
  if (m && m.from === "ext" && typeof m.json === "string") {
    if(m.json===JSON.stringify({type:"bridgeCheck"})){reply({ready:true});return;}
    window.postMessage({ wpExt: "ext", json: m.json }, location.origin);
  }
});

// Presence beacon: page scripts that loaded before us still detect the
// extension, and the worker learns our tab id up front.
pong();
try { chrome.runtime.sendMessage({ from: "app", json: JSON.stringify({ type: "hello" }) }); } catch (e) {}
