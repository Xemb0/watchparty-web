/* Open the provider's actual local settings; never read media or account data. */
(() => {
  if (!/(^|\.)youtube\.com$/.test(location.hostname) || !location.pathname.startsWith('/embed/')) return;
  let generation = 0;
  function closeMenu() {
    document.querySelector('bottom-sheet-container:not([hidden]) .close-button')?.click();
    const menu = document.querySelector('.ytp-settings-menu');
    if (menu && menu.style.display !== 'none') document.querySelector('.ytp-settings-button')?.click();
  }
  window.addEventListener('message', event => {
    if (event.source !== window.parent || !/^https:\/\/(app\.)?watchparty\.online$/.test(event.origin) && !/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(event.origin)) return;
    const m = event.data;
    if (!m || !['open','close'].includes(m.wpSettings)) return;
    const report = status => window.parent.postMessage({wpSettings:'result',requestId:m.requestId,status},event.origin);
    const current = ++generation;
    closeMenu();
    if (m.wpSettings === 'close') { report('closed'); return; }
    const pattern = {quality:/^Quality(?:\s|$)/i,audio:/^Audio (track|language)/i,subtitles:/^(Subtitles\/CC|Captions)/i}[m.section];
    if (!pattern) return;
    if (document.querySelector('.html5-video-player')?.classList.contains('ad-showing')) { report('ad'); return; }
    const gear = document.querySelector('.ytp-settings-button, .player-settings-icon');
    if (!gear) { report('unavailable'); return; }
    gear.click();
    let attempts = 0;
    function selectSection() {
      if (current !== generation) return;
      const row = [...document.querySelectorAll('.ytp-settings-menu .ytp-menuitem, bottom-sheet-container:not([hidden]) [role="menuitem"]')].find(item => {
        const label = item.querySelector('.ytp-menuitem-label, .ytListItemViewModelTitle');
        return pattern.test((label?.textContent || item.textContent || '').trim());
      });
      if (!row) {
        if (++attempts < 10) { setTimeout(selectSection,100); return; }
        closeMenu(); report('unavailable'); return;
      }
      row.click(); report('open');
    }
    setTimeout(selectSection,150);
  });
})();
