/* Shared boundary: never turn a credential-bearing URL into a different URL.
 * Such media stays in its original page/session; only public identities leave it. */
var WatchPartyUrls = (() => {
  const sensitive = /(?:^|[_-])(?:access.?token|refresh.?token|id.?token|token|auth|authorization|jwt|session|sessionid|sid|signature|sig|password|passwd|secret|credential|api.?key|key|code|policy|hmac|hdntl|hdnea)(?:$|[_-])|^x-amz-|^x-goog-/i;
  function shareable(value) {
    try {
      const u = new URL(value);
      if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) return null;
      const h = u.hostname.toLowerCase();
      // Local/intranet pages are not discovery or room-sharing targets.
      if (!h.includes('.') || h.endsWith('.local') || h.endsWith('.localhost') || h.endsWith('.internal') ||
          /^(?:0|10|127|169\.254|192\.168)\./.test(h) || /^172\.(?:1[6-9]|2\d|3[01])\./.test(h) ||
          /^100\.(?:6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(h) || h.startsWith('[')) return null;
      const hashParams = new URL('https://placeholder.invalid/?' + u.hash.slice(1).replace(/^.*\?/, '')).searchParams;
      if ([...u.searchParams.keys(), ...hashParams.keys()].some(k => sensitive.test(k))) return null;
      return u.href;
    } catch (_) { return null; }
  }
  function approvedApp(value) {
    try { return ['https://app.watchparty.online', 'https://watchparty.online'].includes(new URL(value).origin); }
    catch (_) { return false; }
  }
  // Only for an explicitly requested local player; never a room/share URL.
  function localMedia(value) {
    try {
      const u=new URL(value);
      if(u.protocol!=='https:'||u.username||u.password||!shareable(u.origin+u.pathname)||! /\.(mp4|webm|m4v|m3u8)$/i.test(u.pathname))return null;
      return u.href;
    }catch(_){return null;}
  }
  return { shareable, approvedApp, localMedia };
})();
