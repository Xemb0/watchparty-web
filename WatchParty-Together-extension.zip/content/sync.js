/*
 * WatchParty Together — streaming-tab content script.
 *
 * The browser-extension twin of the mobile apps' web_sync.js (see
 * composeApp/src/commonMain/composeResources/files/cowatch/web_sync.js —
 * keep the sync CORE below behaviourally identical when changing either):
 *   - observe the page's <video> (play / pause / seek / 1s time heartbeat)
 *     and report to the room (HOST side),
 *   - apply remote play / pause / seek commands without echoing them back
 *     (PARTICIPANT side, the suppression window),
 * plus two extension-only pieces:
 *   - every report carries location.href + document.title so the app can
 *     start the shared session from the title the user pressed play on,
 *   - a slim "WatchParty" rail pill so the user sees sync state without
 *     switching back to the app tab (single-page feel).
 *
 * Runs in the isolated world: the DOM (and the <video>) is shared with the
 * page, page scripts can't see or tamper with us.
 */
(function () {
  'use strict';
  if (window.__wpExtSync) return;
  window.__wpExtSync = true;

  /* ── transport ─────────────────────────────────────────────────────── */

  var active = false;
  var sweep = null;

  function send(payload) {
    if (!active) return;
    var url = WatchPartyUrls.shareable(location.href);
    if (!url) { stop(); return; }
    payload.ts = Date.now();
    payload.url = url;
    payload.title = (document.title || '')
      // Strip the trailing " - Service" suffix the provider appends, so the
      // room shows a clean title. YouTube watch pages are "<Title> - YouTube";
      // OTT pages are "<Title> - Netflix" etc. (keep mobile web_sync.js twin in sync).
      .replace(/ [-|–] (Netflix|Prime Video|Disney\+|Hulu|Max|Crunchyroll|JioHotstar|YouTube).*$/i, '');
    try { chrome.runtime.sendMessage({ from: 'sync', json: JSON.stringify(payload) }); } catch (e) {}
  }

  /* ── sync core (mirror of web_sync.js) ─────────────────────────────── */

  var applyingUntil = 0;
  var SUPPRESS_MS = 900;
  function suppressing() { return Date.now() < applyingUntil; }

  var lastTimeReport = 0;
  var TIME_REPORT_MS = 1000;

  var video = null;

  function report(action) {
    if (!video || suppressing()) return;
    send({
      type: 'event',
      action: action, // 'play' | 'pause' | 'seek' | 'time' | 'ended'
      position: Math.max(0, video.currentTime || 0),
      duration: isFinite(video.duration) ? video.duration : 0,
      playing: !video.paused,
    });
  }

  var handlers = {
    play: function () { report('play'); },
    pause: function () { report('pause'); },
    seeked: function () { report('seek'); },
    ended: function () { report('ended'); },
    timeupdate: function () {
      var now = Date.now();
      if (now - lastTimeReport < TIME_REPORT_MS) return;
      lastTimeReport = now;
      report('time');
    },
  };

  function hook(v) {
    if (!v || v === video) return;
    unhook();
    video = v;
    for (var k in handlers) v.addEventListener(k, handlers[k]);
    send({ type: 'ready', position: v.currentTime || 0, playing: !v.paused });
  }

  function unhook() {
    if (!video) return;
    for (var k in handlers) {
      try { video.removeEventListener(k, handlers[k]); } catch (e) {}
    }
    video = null;
  }

  function findVideo() {
    var vids = document.querySelectorAll('video');
    if (!vids.length) return null;
    var best = null, bestArea = 0, playing = null, playingArea = -1;
    for (var i = 0; i < vids.length; i++) {
      var r = vids[i].getBoundingClientRect();
      var area = r.width * r.height;
      if (area > bestArea) { bestArea = area; best = vids[i]; }
      if (!vids[i].paused && !vids[i].ended && area > playingArea) { playingArea = area; playing = vids[i]; }
    }
    if (playing) return playing;
    // Keep pause/seek commands on the title rather than its mounted preview.
    if (video && video.isConnected && Array.prototype.includes.call(vids, video)) return video;
    // A participant's streaming tab is often BACKGROUNDED, where an unpainted
    // <video> reports a 0x0 rect — don't let that stop the hook (it would
    // strand the whole session on that peer). Fall back to the one with
    // duration, else the first element.
    if (best) return best;
    for (var j = 0; j < vids.length; j++) {
      if (isFinite(vids[j].duration) && vids[j].duration > 0) return vids[j];
    }
    return vids[0];
  }

  function poll() {
    // Providers may keep the preview mounted when the full player opens.
    var v = findVideo();
    if (v && v !== video) hook(v);
    else if (!v && video) unhook();
  }

  function start() {
    if (active || !WatchPartyUrls.shareable(location.href)) return;
    active = true;
    rail.ensure();
    poll();
    sweep = setInterval(poll, 1000);
  }

  function stop() {
    active = false;
    if (sweep !== null) clearInterval(sweep);
    sweep = null;
    unhook();
    applyingUntil = 0;
    rail.remove();
  }

  function applyCommand(action, positionSec) {
    if (!video || !video.isConnected) { var v = findVideo(); if (v) hook(v); }
    if (!video) return;
    applyingUntil = Date.now() + SUPPRESS_MS;
    try {
      if (typeof positionSec === 'number' && positionSec >= 0) {
        // Deadband: needless seeks re-buffer DRM streams and CAUSE the
        // stutter they're meant to fix.
        if (Math.abs((video.currentTime || 0) - positionSec) > 1.2) {
          video.currentTime = positionSec;
        }
      }
      if (action === 'play') { var p = video.play(); if (p && p.catch) p.catch(function () {}); }
      else if (action === 'pause') { video.pause(); }
    } catch (e) {}
  }

  /* ── commands + state from the room ────────────────────────────────── */

  chrome.runtime.onMessage.addListener(function (m) {
    if (!m || m.from !== 'ext-bg' || typeof m.json !== 'string') return;
    var msg;
    try { msg = JSON.parse(m.json); } catch (e) { return; }
    if (msg.type === 'activate') {
      start();
    } else if (msg.type === 'command' && active) {
      applyCommand(msg.action, msg.positionSec);
    } else if (msg.type === 'state' && active) {
      rail.update(msg);

    } else if (msg.type === 'cancelDiscovery') {
      if (!active) rail.remove();
    } else if (msg.type === 'close') {
      stop();
    }
  });

  /* ── WatchParty rail (single-page feel on the streaming tab) ───────── */

  var rail = (function () {
    var host = null, dot = null, label = null;
    function control(type) {
      try { chrome.runtime.sendMessage({from:'sync',json:JSON.stringify({type:type})}); } catch (_) {}
    }

    function ensure() {
      if (host && host.isConnected) return;
      host = document.createElement('div');
      host.style.cssText =
        'position:fixed;top:14px;right:14px;z-index:2147483647;pointer-events:auto;';
      var shadow = host.attachShadow({ mode: 'closed' });
      var pill = document.createElement('div');
      pill.style.cssText =
        'display:flex;align-items:center;gap:7px;padding:7px 12px;' +
        'background:rgba(12,8,24,.82);border:1px solid rgba(167,139,250,.35);' +
        'border-radius:999px;font:600 12px system-ui,sans-serif;color:#fff;' +
        'backdrop-filter:blur(6px);user-select:none;';
      dot = document.createElement('span');
      dot.style.cssText =
        'width:8px;height:8px;border-radius:50%;background:#FBBF24;flex:none;';
      label = document.createElement('button');
      label.type = 'button';
      label.title = 'Open your WatchParty room';
      label.style.cssText = 'border:0;background:none;color:inherit;font:inherit;padding:3px;cursor:pointer;';
      label.textContent = 'WatchParty · Waiting for video';
      label.onclick = function () { control('openRoom'); };
      var close = document.createElement('button');
      close.type = 'button';
      close.title = 'Stop syncing';
      close.setAttribute('aria-label', 'Stop syncing');
      close.textContent = '×';
      close.style.cssText =
        'cursor:pointer;margin-left:2px;font-size:18px;line-height:1;padding:6px;border:0;background:none;color:inherit;';
      close.onclick = function () { stop(); control('disconnect'); };
      pill.appendChild(dot); pill.appendChild(label); pill.appendChild(close);
      shadow.appendChild(pill);
      (document.body || document.documentElement).appendChild(host);
    }

    function update(state) {
      ensure();
      var playing = state.phase === 'PLAYING';
      dot.style.background = playing ? '#34D399' : '#FBBF24';
      label.textContent =
        'WatchParty · ' + (state.isHost ? 'Hosting' : 'Following host') +
        (playing ? '' : ' · paused');
    }

    function remove() {
      if (host) { try { host.remove(); } catch (e) {} host = null; }
    }

    return { update: update, remove: remove, ensure: ensure };
  })();

  // No DOM observation until the worker confirms this is the selected tab.
  try { chrome.runtime.sendMessage({ from: 'sync', json: JSON.stringify({ type: 'attached' }) }); } catch (_) {}
})();
