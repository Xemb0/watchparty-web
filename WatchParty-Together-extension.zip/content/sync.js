/*
 * WatchParty Together — streaming-tab content script.
 *
 * The browser-extension twin of the mobile apps' web_sync.js (see
 * composeApp/src/commonMain/composeResources/files/cowatch/web_sync.js —
 * keep the sync CORE below behaviourally identical when changing either):
 *   - observe the page's <video> (play / pause / seek / 1s time heartbeat)
 *     and report to the room (HOST side),
 *   - apply remote play / pause / seek commands without echoing them back
 *     (PARTICIPANT side, the suppression window),
 * plus two extension-only pieces:
 *   - every report carries location.href + document.title so the app can
 *     start the shared session from the title the user pressed play on,
 *   - a slim "WatchParty" rail pill so the user sees sync state without
 *     switching back to the app tab (single-page feel).
 *
 * Runs in the isolated world: the DOM (and the <video>) is shared with the
 * page, page scripts can't see or tamper with us.
 */
(function () {
  'use strict';
  if (window.__wpExtSync) return;
  window.__wpExtSync = true;

  /* ── transport ─────────────────────────────────────────────────────── */

  function send(payload) {
    payload.ts = Date.now();
    payload.url = location.href;
    payload.title = (document.title || '').replace(/ [-|–] (Netflix|Prime Video|Disney\+|Hulu|Max|Crunchyroll|JioHotstar).*$/i, '');
    try { chrome.runtime.sendMessage({ from: 'sync', json: JSON.stringify(payload) }); } catch (e) {}
  }

  /* ── sync core (mirror of web_sync.js) ─────────────────────────────── */

  var applyingUntil = 0;
  var SUPPRESS_MS = 900;
  function suppressing() { return Date.now() < applyingUntil; }

  var lastTimeReport = 0;
  var TIME_REPORT_MS = 1000;

  var video = null;

  function report(action) {
    if (!video || suppressing()) return;
    send({
      type: 'event',
      action: action, // 'play' | 'pause' | 'seek' | 'time' | 'ended'
      position: Math.max(0, video.currentTime || 0),
      duration: isFinite(video.duration) ? video.duration : 0,
      playing: !video.paused,
    });
  }

  var handlers = {
    play: function () { report('play'); },
    pause: function () { report('pause'); },
    seeked: function () { report('seek'); },
    ended: function () { report('ended'); },
    timeupdate: function () {
      var now = Date.now();
      if (now - lastTimeReport < TIME_REPORT_MS) return;
      lastTimeReport = now;
      report('time');
    },
  };

  function hook(v) {
    if (!v || v === video) return;
    unhook();
    video = v;
    for (var k in handlers) v.addEventListener(k, handlers[k]);
    send({ type: 'ready', position: v.currentTime || 0, playing: !v.paused });
  }

  function unhook() {
    if (!video) return;
    for (var k in handlers) {
      try { video.removeEventListener(k, handlers[k]); } catch (e) {}
    }
    video = null;
  }

  function findVideo() {
    var vids = document.querySelectorAll('video');
    if (!vids.length) return null;
    var best = null, bestArea = 0;
    for (var i = 0; i < vids.length; i++) {
      var r = vids[i].getBoundingClientRect();
      var area = r.width * r.height;
      if (area > bestArea) { bestArea = area; best = vids[i]; }
    }
    // A participant's streaming tab is often BACKGROUNDED, where an unpainted
    // <video> reports a 0x0 rect — don't let that stop the hook (it would
    // strand the whole session on that peer). Fall back to the one with
    // duration, else the first element.
    if (best) return best;
    for (var j = 0; j < vids.length; j++) {
      if (isFinite(vids[j].duration) && vids[j].duration > 0) return vids[j];
    }
    return vids[0];
  }

  // Skip the DOM sweep while the hooked video is still live (same low-end
  // guard the app's web_sync.js uses).
  setInterval(function () {
    if (video && video.isConnected) return;
    var v = findVideo();
    if (v && v !== video) hook(v);
  }, 1000);

  function applyCommand(action, positionSec) {
    if (!video || !video.isConnected) { var v = findVideo(); if (v) hook(v); }
    if (!video) return;
    applyingUntil = Date.now() + SUPPRESS_MS;
    try {
      if (typeof positionSec === 'number' && positionSec >= 0) {
        // Deadband: needless seeks re-buffer DRM streams and CAUSE the
        // stutter they're meant to fix.
        if (Math.abs((video.currentTime || 0) - positionSec) > 1.2) {
          video.currentTime = positionSec;
        }
      }
      if (action === 'play') { var p = video.play(); if (p && p.catch) p.catch(function () {}); }
      else if (action === 'pause') { video.pause(); }
    } catch (e) {}
  }

  /* ── commands + state from the room ────────────────────────────────── */

  chrome.runtime.onMessage.addListener(function (m) {
    if (!m || m.from !== 'ext-bg' || typeof m.json !== 'string') return;
    var msg;
    try { msg = JSON.parse(m.json); } catch (e) { return; }
    if (msg.type === 'command') {
      applyCommand(msg.action, msg.positionSec);
    } else if (msg.type === 'state') {
      rail.update(msg);
    } else if (msg.type === 'close') {
      rail.remove();
    }
  });

  /* ── WatchParty rail (single-page feel on the streaming tab) ───────── */

  var rail = (function () {
    var host = null, dot = null, label = null;

    function ensure() {
      if (host && host.isConnected) return;
      host = document.createElement('div');
      host.style.cssText =
        'position:fixed;top:14px;right:14px;z-index:2147483647;pointer-events:auto;';
      var shadow = host.attachShadow({ mode: 'closed' });
      var pill = document.createElement('div');
      pill.style.cssText =
        'display:flex;align-items:center;gap:7px;padding:7px 12px;' +
        'background:rgba(12,8,24,.82);border:1px solid rgba(167,139,250,.35);' +
        'border-radius:999px;font:600 12px system-ui,sans-serif;color:#fff;' +
        'backdrop-filter:blur(6px);user-select:none;';
      dot = document.createElement('span');
      dot.style.cssText =
        'width:8px;height:8px;border-radius:50%;background:#FBBF24;flex:none;';
      label = document.createElement('span');
      label.textContent = 'WatchParty · connecting…';
      var close = document.createElement('span');
      close.textContent = '×';
      close.style.cssText =
        'cursor:pointer;margin-left:2px;opacity:.7;font-size:14px;line-height:1;';
      close.onclick = function () { remove(); };
      pill.appendChild(dot); pill.appendChild(label); pill.appendChild(close);
      shadow.appendChild(pill);
      (document.body || document.documentElement).appendChild(host);
    }

    function update(state) {
      ensure();
      var playing = state.phase === 'PLAYING';
      dot.style.background = playing ? '#34D399' : '#FBBF24';
      label.textContent =
        'WatchParty · ' + (state.isHost ? 'Hosting' : 'Synced') +
        (playing ? '' : ' · paused');
    }

    function remove() {
      if (host) { try { host.remove(); } catch (e) {} host = null; }
    }

    return { update: update, remove: remove, ensure: ensure };
  })();

  rail.ensure();
})();
